
<!DOCTYPE html>
<html>
<head>
  <title>Registration system</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <div class="header">
  	<h2>Register</h2>
  </div>
	
  <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
 
<div class="input-group">
      <label>Name</label>
      <input type="text" name="name" >
    </div>

<div class="input-group">
      <label>Email</label>
      <input type="email" name="email" >
    </div>
    <div class="input-group">
  	  <label>Username</label>
  	  <input type="text" name="username" >
  	</div>
  	
  	<div class="input-group">
  	  <label>Password</label>
  	  <input type="password" name="password_1">
  	</div>
  	<div class="input-group">
  	  <label>Confirm password</label>
  	  <input type="password" name="password_2">
  	</div>
    <div class="input-group">
      <label>Gender</label>
     <label> <input type="radio" name="male" value="other">Male</label><br> <label><input type="radio" name="female" value="female">Female </label><br>  <label><input type="radio" name="other" value="other">Other</label>
      
    </div>

<div class="input-group">
      <label>DOB</label>
      <input type="datetime" name="datetime" >  
    </div>


  	<div class="input-group">
  	  <button type="submit" class="btn" name="reg_user">submit</button>
  	</div>
    <div class="input-group">
      <button type="reset" class="btn" name="reg_user">reset</button>
    </div>
  	<p>
  		Already a member? <a href="login.php">Sign in</a>
  	</p>

  </form>
  <?php
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "xcompany";

  // Create connection
  $conn = new mysqli($servername, $username, $password, $dbname);
  // Check connection
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }
  if($_SERVER["REQUEST_METHOD"] == "POST")
  {
    $sql = "INSERT INTO users (name, email,username,password)
    VALUES ('".$_POST["name"]."','".$_POST["email"]."','".$_POST["username"]."','".$_POST["password_1"]."')";

    if ($conn->query($sql) === TRUE) {
      echo "New record created successfully";
    } 
    else {
      echo "Error: " . $sql . "<br>" . $conn->error;
    }
  }
  

  $conn->close();
?>
</body>
</html>